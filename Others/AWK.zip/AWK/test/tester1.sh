IN='

'
OUT='

'
diff <(echo "$IN" | awk -f script.awk) <(echo "$OUT")